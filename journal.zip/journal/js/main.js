document.addEventListener('DOMContentLoaded', function() {
  const burger = document.querySelector('.burger');
  const menu = document.querySelector('.menu__inner');

  if (burger && menu) {
    burger.addEventListener('click', function() {
      menu.classList.toggle('active');
      burger.classList.toggle('active');
      document.body.classList.toggle('active');
    });
  }
});
document.addEventListener('DOMContentLoaded', function() {
  const marqueeContainer = document.querySelector('.marquee-container');
  const marquee = document.querySelector('.marquee');

  if (window.innerWidth > 1920) {
    // Функция для добавления повторяющегося текста в marquee
    function fillMarquee() {
      const containerWidth = marqueeContainer.offsetWidth;
      let marqueeWidth = marquee.scrollWidth;
      
      // Добавляем <span> пока ширина marquee не заполнит экран
      while (marqueeWidth < containerWidth*2) {
        const span = document.createElement('span');
        span.textContent = 'Журнал о системах письма и экологичном отношении с информацией.';
        marquee.appendChild(span);
        
        // Пересчитываем ширину
        marqueeWidth = marquee.scrollWidth;
      }
    }
    
    fillMarquee(); // Вызываем функцию для добавления текста
  }
});
document.addEventListener("DOMContentLoaded", () => {
  // Получаем все элементы с классом `tagnum`
  const tags = document.querySelectorAll(".footnote__num");

  tags.forEach((tag, index) => {
    // Устанавливаем номер сноски внутри самого элемента label
    const footnoteNumber = index + 1;
    tag.textContent = footnoteNumber;  // Отображаем номер сноски внутри <label>

    // Устанавливаем номер сноски внутри .footnote__num
    const footnoteNum = tag.querySelector(".tagnum");
    if (footnoteNum) {
      footnoteNum.textContent = footnoteNumber;
    }
  });
});
document.addEventListener("DOMContentLoaded", () => {
  // Get all elements with the class `tagnum`
  const tags = document.querySelectorAll(".tagnum");

  tags.forEach((tag, index) => {
    // Assign a sequential number to each `data-number` attribute
    tag.setAttribute("data-number", index + 1);

    // Find `.footnote__num` within the tag and set its content
    const footnoteNum = tag.querySelector(".footnote__num");
    if (footnoteNum) {
      footnoteNum.textContent = index + 1;
    }
  });
});
document.addEventListener('DOMContentLoaded', function() {
  // Получаем все метки с классом .tagnum
  const tagnums = document.querySelectorAll('.tagnum');

  tagnums.forEach(function(tagnum) {
    // Добавляем обработчик для каждой метки
    tagnum.addEventListener('click', function() {
      // Находим родительский элемент с сноской
      const footnote = tagnum.nextElementSibling;

      if (footnote) {
        // Переключаем класс 'active' для сноски
        footnote.classList.toggle('active');
      }
    });
  });
});
document.addEventListener('DOMContentLoaded', function () {
  const backButton = document.querySelector('.article__btn-back');
  
  backButton.addEventListener('click', function () {
    window.scrollTo({
      top: 0
    });
  });
});
document.querySelectorAll('.article__text-link').forEach(link => {
  const tooltip = link.querySelector('.tooltip');

  link.addEventListener('mouseenter', () => {
    tooltip.style.display = 'block';

    const linkRect = link.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();

    let offsetX = 10; // Добавляет небольшой отступ от ссылки
    let offsetY = -tooltipRect.height - 10; // Смещает вверх с отступом

    // Проверяем, если подсказка выходит за границы экрана
    if (linkRect.left + tooltipRect.width > window.innerWidth) {
      offsetX = -(tooltipRect.width - linkRect.width);
    } else if (linkRect.left < 0) {
      offsetX = -linkRect.left;
    }
    tooltip.style.left = `${offsetX}px`;
  });

  link.addEventListener('mouseleave', () => {
    tooltip.style.display = 'none';
  });
});
document.addEventListener('DOMContentLoaded', () => {
  const filters = document.querySelectorAll('.filter__filtres-item'); // Фильтры
  const tags = document.querySelectorAll('.filter__tags-item'); // Теги
  const articles = document.querySelectorAll('.filter__content-item'); // Статьи

  let activeFilter = ''; // Активный фильтр
  let activeTags = new Set(); // Активные теги
  let isDateAscending = false; // Порядок сортировки по дате

  const dateFilter = document.querySelector('.date-filter'); // Элемент фильтра "Дата"

  // Обработка клика по фильтрам
  filters.forEach(filter => {
    filter.addEventListener('click', () => {
      const filterText = filter.textContent.trim();
      console.log('Выбран фильтр:', filterText); // Лог для проверки

      filters.forEach(f => f.classList.remove('active'));
      filter.classList.add('active');

      if (filterText === 'Дата') {
        isDateAscending = !isDateAscending; // Переключаем порядок сортировки
        activeFilter = 'Дата';

        if (isDateAscending) {
          dateFilter.classList.remove('descending');
        } else {
          dateFilter.classList.add('descending');
        }
      } else if (filterText === 'Название') {
        activeFilter = 'Название';
      } else {
        activeFilter = filterText;
      }

      applyFilters();
    });
  });

  // Обработка клика по тегам
  tags.forEach(tag => {
    tag.addEventListener('click', () => {
      const tagText = tag.textContent.trim();
      console.log('Выбран тег:', tagText); // Лог для проверки

      if (tagText === 'Все') {
        activeTags.clear();
        tags.forEach(t => t.classList.remove('active'));
        tag.classList.add('active');
      } else {
        tag.classList.toggle('active');
        if (tag.classList.contains('active')) {
          activeTags.add(tagText);
        } else {
          activeTags.delete(tagText);
        }

        if (activeTags.size > 0) {
          tags[0].classList.remove('active'); // Убираем "active" с "Все"
        }
      }

      applyFilters();
    });
  });

  // Сортировка по алфавиту
  function sortArticlesAlphabetically(articlesArray) {
    return articlesArray.sort((a, b) => {
      const titleA = a.querySelector('.filter__content-title h3').textContent.trim();
      const titleB = b.querySelector('.filter__content-title h3').textContent.trim();
      return titleA.localeCompare(titleB);
    });
  }

  // Сортировка по дате
  function sortArticlesByDate(articlesArray) {
    return articlesArray.sort((a, b) => {
      const dateA = new Date(a.querySelector('.filter__content-data').getAttribute('data-date'));
      const dateB = new Date(b.querySelector('.filter__content-data').getAttribute('data-date'));
      return isDateAscending ? dateA - dateB : dateB - dateA;
    });
  }

  // Применение фильтров и сортировки
  function applyFilters() {
    const articlesArray = Array.from(articles);

    // Применение сортировки в зависимости от активного фильтра
    if (activeFilter === 'Дата') {
      sortArticlesByDate(articlesArray);
    } else if (activeFilter === 'Название') {
      sortArticlesAlphabetically(articlesArray);
    }

    // Обновление порядка статей
    const contentContainer = document.querySelector('.filter__content');
    articlesArray.forEach(article => contentContainer.appendChild(article));

    // Применяем фильтрацию по тегам и фильтрам
    articlesArray.forEach(article => {
      const matchesFilter = filterArticle(article);
      const matchesTag = tagArticle(article);
      article.style.display = matchesFilter && matchesTag ? '' : 'none';
    });
  }

  // Фильтрация по активному фильтру
  function filterArticle(article) {
    if (!activeFilter || activeFilter === 'Топ статей') return true;

    if (activeFilter === 'Топ статей') {
      const likes = parseInt(article.querySelector('.issue-item__count-likes').textContent.trim());
      const views = parseInt(article.querySelector('.issue-item__count-views').textContent.trim());
      const coefficient = likes / views;
      return coefficient > 0.5;
    }

    return true;
  }

  // Фильтрация по тегам
  function tagArticle(article) {
    if (activeTags.size === 0 || activeTags.has('Все')) return true;
    const articleTag = article.querySelector('.filter__content-tag').textContent.trim();
    return activeTags.has(articleTag);
  }
});
